<!DOCTYPE html>
<html lang="en">
<head>
  <title>Flair Airline Bookings</title>
  <!-- Material Design fonts -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

	<!-- Bootstrap Material Design -->
	<link rel="stylesheet" href="https://cdn.rawgit.com/FezVrasta/bootstrap-material-design/dist/dist/bootstrap-material-design.min.css">
</head>

	<nav class="navbar navbar-default">
	    <div class="container-fluid">		       
	        <div class="navbar-header">
	            <a class="navbar-brand" href="#">Flair Airline Booking</a>
	        </div>	       
	    </div>
	</nav>